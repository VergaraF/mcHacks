var admins = require('../config/administrators.json');

// Map routes to controller functions
module.exports = function(router) {
  router.get('/error', function(req, resp) {
    throw new Error('Derp. An error occurred.');
  });

  router.get('/sms', function(req, resp) {
  	resp.send("Hello world2");
  	twilioClient.sendSms(admin.phoneNumber, messageToSend);
  });

};

