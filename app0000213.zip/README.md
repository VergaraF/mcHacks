# mcHacks
Hackathon at McGill University
